# CLAU
 TCC Etec - Sistema de Gerenciamento Escolar
